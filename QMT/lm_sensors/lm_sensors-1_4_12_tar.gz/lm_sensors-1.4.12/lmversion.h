#define LM_DATE "19981230"
#define LM_VERSION "1.4.12"
