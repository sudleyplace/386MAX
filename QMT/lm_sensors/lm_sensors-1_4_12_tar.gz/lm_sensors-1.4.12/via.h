#ifndef PCI_DEVICE_ID_VIA_82C586_3
#define PCI_DEVICE_ID_VIA_82C586_3     0x3040
#endif

/* VIA Power management registers */
#define PM_IO_BASE_REGISTER 0x48
#define I2C_DIR		(pm_io_base+0x40)
#define I2C_OUT		(pm_io_base+0x42)
#define I2C_IN		(pm_io_base+0x44)
#define I2C_SCL		0x02
#define I2C_SDA		0x04

/* io-region reservation */
#define IOSPACE		0x06
#define IOTEXT		"VIA SMBus"

/* protocol timing and address retrys */
#define TIMEOUT 1000
#define BIT_DELAY 10
#define RETRIES 1

extern int SMBus_Via_Init(void);
extern int SMBus_Via_Access(u8 addr, char read_write, u8 command, int size,
				union SMBus_Data *data);
extern void SMBus_Via_Cleanup(void);

